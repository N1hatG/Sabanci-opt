Format of the input files:

first line: two integers seperated by spaces:
N(number of communities) M(number of healthcenters)

other lines: five values seperated by spaces: 
community(node)_index  x-coordinate y-coordinate  C(capacity of a healthcenter if deployed) population_size 